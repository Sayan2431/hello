package model;

import java.sql.*;

public interface DAO {

	int insert(String query) throws Exception;
	int update(String query) throws Exception;
	int delete(String query) throws Exception;
	ResultSet select(String query) throws Exception;
	
}
