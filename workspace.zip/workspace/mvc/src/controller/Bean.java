package controller;

import java.sql.ResultSet;

import model.DAOImpl;

public class Bean {

	public String buildQuery(String id,String pswd) throws Exception
	{
		DAOImpl daoimpl=new DAOImpl();
		String query="select type from usertab where userid='"+id+"' and password='"+pswd+"'";
		ResultSet rs=daoimpl.select(query);
		if(rs.next())
		{
			return rs.getString(1);
		}
		else
		{
			return "invalid userid or password";
		}
		
	}
	
	
	public String insertQuery(String uid,String ps,String t) throws Exception
	{
		DAOImpl daoimpl=new DAOImpl();
		String query="insert into usertab values('"+uid+"','"+ps+"','"+t+"')";
		int j=daoimpl.insert(query);
		if(j!=0)
		{
			return "Insertion successful";
		}
		else
			return "Insertion failed";
		
	}
	
	public String updateQuery(String uid,String ps) throws Exception
	{
		DAOImpl daoimpl=new DAOImpl();
		String query="update usertab set password='"+ps+"' where userid='"+uid+"'";
		int j=daoimpl.update(query);
		if(j!=0)
		{
			return "Update successful";
		}
		else
			return "Update failed";
		
	}
	
	public String deleteQuery(String uid) throws Exception
	{
		DAOImpl daoimpl=new DAOImpl();
		String query="delete from usertab where userid='"+uid+"'";
		int j=daoimpl.delete(query);
		if(j!=0)
		{
			return "Deletion successful";
		}
		else
			return "Deletion failed";
		
	}
	
	
	
}
