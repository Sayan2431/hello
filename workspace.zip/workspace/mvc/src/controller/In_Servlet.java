package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class In_Servlet
 */
@WebServlet("/In_Servlet")
public class In_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public In_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uid=request.getParameter("uid");
		String ps=request.getParameter("ps");
		String t=request.getParameter("t");
		Bean b=new Bean();
		try{
			String output=b.insertQuery(uid, ps, t);
			PrintWriter out=response.getWriter();
			out.println(output);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
