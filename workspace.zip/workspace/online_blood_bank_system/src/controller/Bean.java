package controller;

import model.DAOImpl;
import java.sql.*;

public class Bean {

	public String insertQuery(String first_name,String last_name,int age,String gender,String contact_number,String email,String password,String weight,String state,String area,String pin_code,String blood_group) throws Exception
	{
		DAOImpl daoimpl=new DAOImpl();
		String query="insert into table1 values('"+first_name+"','"+last_name+"','"+age+"','"+gender+"','"+contact_number+"','"+email+"','"+password+"','"+weight+"','"+state+"','"+area+"','"+pin_code+"','"+blood_group+"')";
		int j=daoimpl.insert(query);
		if(j!=0)
		{
			return "Insertion successful";
		}
		else
			return "Insertion failed";
		
	}
}
