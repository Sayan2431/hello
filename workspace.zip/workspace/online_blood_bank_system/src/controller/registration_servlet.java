package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registration_servlet
 */
@WebServlet("/registration_servlet")
public class registration_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registration_servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String first_name=request.getParameter("first_name");
		String last_name=request.getParameter("last_name");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		String contact_number=request.getParameter("contact_number");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String weight=request.getParameter("weight");
		String state=request.getParameter("state");
		String area=request.getParameter("area");
		String pin_code=request.getParameter("pin_code");
		String blood_group=request.getParameter("blood_group");
		Bean b=new Bean();
		try{
			String output=b.insertQuery(first_name, last_name, age, gender, contact_number, email, password, weight, state, area, pin_code, blood_group);
			PrintWriter out=response.getWriter();
			out.println(output);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
