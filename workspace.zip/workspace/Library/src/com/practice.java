package com;
import java.util.*;

import javax.management.RuntimeErrorException;

public class practice {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet ts=new TreeSet();
		ts.add(2);
		ts.add(3);
		ts.add(7);
		
		ts.add(1);
		ts.add(8);
		SortedSet ss=ts.subSet(1, 7);
		ss.add(4);
		ss.add(6);
		ss.add(5);
		//ss.add(7);
		System.out.print(ss);
	}

}
