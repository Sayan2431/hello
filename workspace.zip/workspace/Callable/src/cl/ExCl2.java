package cl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Types;

public class ExCl2 {
	public static void main(String[] args) throws Exception{
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url,"hr","hr");
		Statement st=con.createStatement();
		
		CallableStatement stmt=con.prepareCall("{?= call fun1(?,?)}");
		stmt.setInt(2,1);
		stmt.setInt(3,15000);
		stmt.registerOutParameter(1,Types.INTEGER);
		stmt.execute();
		System.out.println("procedure executed with id "+stmt.getInt(1));

	}
}
