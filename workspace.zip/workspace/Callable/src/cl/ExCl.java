package cl;
import java.sql.*;

public class ExCl {

	public static void main(String[] args) throws Exception{
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url,"hr","hr");
		Statement st=con.createStatement();
		
		CallableStatement stmt=con.prepareCall("{call p1(?,?)}");
		stmt.setInt(1,1);
		stmt.setInt(2,60000);
		stmt.execute();
		System.out.println("procedure executed");

	}

}
