package com.dm;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class jdbc_info {
	public static void main(String[] args)
	{
		try{
			String driver="oracle.jdbc.driver.OracleDriver";
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,"hr","hr");
			DatabaseMetaData dbmd=con.getMetaData();
			System.out.println("Driver Name:"+dbmd.getDriverName());
			System.out.println("Driver Version:"+dbmd.getDriverVersion());
			System.out.println("Driver User Name:"+dbmd.getUserName());
			System.out.println("Driver Product Name:"+dbmd.getDatabaseProductName());
			System.out.println("Driver Product Version:"+dbmd.getDatabaseProductVersion());
			
			
			PreparedStatement ps=con.prepareStatement("select * from employees");
			ResultSet rs=ps.executeQuery();
			ResultSetMetaData rsmd=rs.getMetaData();
			System.out.println("Total Columns:"+rsmd.getColumnCount());
			System.out.println("Column Name of 1st column:"+rsmd.getColumnName(1));
			System.out.println("Column Type Name of 1st column:"+rsmd.getColumnTypeName(1));
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
