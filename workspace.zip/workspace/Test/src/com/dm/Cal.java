package com.dm;

public class Cal {
	public int add(int x,int y)
	{
		return x+y;
	}
}
