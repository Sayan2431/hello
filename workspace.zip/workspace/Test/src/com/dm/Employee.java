package com.dm;

public class Employee {
	String name;
	double salary;
	int empid;
	public Employee(String name, double salary, int empid) {
		super();
		this.name = name;
		this.salary = salary;
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public int getEmpid() {
		return empid;
	}
	
	
}
