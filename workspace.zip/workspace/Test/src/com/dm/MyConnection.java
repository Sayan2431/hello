package com.dm;
import java.sql.*;
import java.sql.DriverManager;

public class MyConnection {

	public static Connection createCon() throws Exception {
		// TODO Auto-generated method stub
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url,"hr","hr");
		return con;
		
	}

}
