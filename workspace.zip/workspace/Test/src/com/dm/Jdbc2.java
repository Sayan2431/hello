package com.dm;
import java.sql.*;

public class Jdbc2 {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		// TODO Auto-generated method stub
		//Common lines for all JDBC connection with Oracle
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url,"hr","hr");
		Statement st=con.createStatement();
		//System.out.println("Connection established");
		//End of the common lines
		
		String query="select last_name,first_name,salary from employees";
		ResultSet rs=st.executeQuery(query);
		System.out.println("Last_name	First_name	Salary");
		while(rs.next())
		{
			String nm1=rs.getString(1);
			String nm2=rs.getString(2);
			String sal=rs.getString("salary");
			
			System.out.println(nm1+"	"+nm2+"		"+sal);
		}
		
	}

}
