package com.dm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class jdbc_searchid {

	public static void main(String[] args) throws ClassNotFoundException,SQLException  {
		// TODO Auto-generated method stub
				//Common lines for all JDBC connection with Oracle
				String driver="oracle.jdbc.driver.OracleDriver";
				String url="jdbc:oracle:thin:@localhost:1521:XE";
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url,"hr","hr");
				Statement st=con.createStatement();
				//System.out.println("Connection established");
				//End of the common lines
				
				System.out.println("Enter employee id");
				Scanner sc=new Scanner(System.in);
				int n=sc.nextInt();
				String query="select last_name,first_name,salary from employees where employee_id="+n+"";
				ResultSet rs=st.executeQuery(query);
				System.out.println("Last_name	First_name	Salary");
				if(rs.next())
				{
				
					String nm1=rs.getString(1);
					String nm2=rs.getString(2);
					String sal=rs.getString("salary");
					
					System.out.println(nm1+"	"+nm2+"		"+sal);
				}
				
			}

		}
