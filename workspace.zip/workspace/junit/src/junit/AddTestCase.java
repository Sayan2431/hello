package junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AddTestCase {

	@Test
	public void testAdd() {
		assertEquals(16, new Add().add());
	}

}
