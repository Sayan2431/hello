package junit;

public class Add {

	int x=9;
	int y=7;
	int add()
	{
		return x+y;
	}
}
