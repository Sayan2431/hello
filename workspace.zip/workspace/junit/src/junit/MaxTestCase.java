package junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class MaxTestCase {

	@Test
	public void testMax() {
		assertEquals(10, new Max().max(4,-6,7,3,5,0,10));
	}
	

}
